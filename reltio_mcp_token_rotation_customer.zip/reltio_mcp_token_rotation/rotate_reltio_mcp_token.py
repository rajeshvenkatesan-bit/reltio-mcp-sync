#!/usr/bin/env python3
"""
Reltio → Acceldata (ADOC/ADM) MCP Bearer token rotator

Fetches a short-lived Reltio OAuth access token (client_credentials) and
updates the Authorization header on an Acceldata MCP server so ADM keeps
a valid Bearer token without manual UI edits.

Requires: Python 3.9+ only (stdlib). Optional: `requests` if already installed.
No pip install is required.

One-shot
  cp .env.example .env   # fill in your values
  python3 rotate_reltio_mcp_token.py

Auto-rotate
  python3 rotate_reltio_mcp_token.py --loop

Cron (tokens typically last ~9h — refresh every 6h)
  0 */6 * * * cd /path/to/reltio_mcp_token_rotation && /usr/bin/env python3 rotate_reltio_mcp_token.py >> rotate.log 2>&1
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import requests  # optional
except ImportError:
    requests = None  # type: ignore


SCRIPT_DIR = Path(__file__).resolve().parent
RELTIO_TOKEN_URL_DEFAULT = "https://auth.reltio.com/oauth/token"
DEFAULT_MCP_NAME = "Reltio MCP"
DEFAULT_REFRESH_BUFFER_SEC = 30 * 60


def load_dotenv(path: Path, override: bool = True) -> None:
    """Load KEY=VALUE from .env into os.environ.

    Values may be single- or double-quoted. Prefer .env over a pre-exported
    shell value (override=True) so secrets with `$`/`*` are not corrupted by
    accidental `source .env` without quotes.
    """
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ("'", '"'):
            val = val[1:-1]
        if key and (override or key not in os.environ):
            os.environ[key] = val


def _env(name: str, default: Optional[str] = None, required: bool = False) -> str:
    val = os.environ.get(name, default)
    if required and not val:
        raise SystemExit(f"Missing required env var: {name} (set in .env or export)")
    return val or ""


def http_json(
    method: str,
    url: str,
    headers: Optional[Dict[str, str]] = None,
    body: Optional[Any] = None,
    form_body: Optional[str] = None,
    timeout: int = 45,
) -> Dict[str, Any]:
    """HTTP JSON helper — uses requests if present, else stdlib urllib."""
    hdrs = dict(headers or {})

    if requests is not None:
        kwargs: Dict[str, Any] = {"headers": hdrs, "timeout": timeout}
        if body is not None:
            kwargs["json"] = body
        elif form_body is not None:
            kwargs["data"] = form_body
        resp = requests.request(method, url, **kwargs)
        if resp.status_code >= 400:
            raise RuntimeError(f"HTTP {resp.status_code} {method} {url}: {resp.text[:500]}")
        return resp.json() if resp.text else {}

    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    elif form_body is not None:
        data = form_body.encode("utf-8")
        hdrs.setdefault("Content-Type", "application/x-www-form-urlencoded")
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        err_body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} {method} {url}: {err_body[:500]}") from exc


def fetch_reltio_token(client_id: str, client_secret: str, timeout: int = 30) -> Dict[str, Any]:
    """OAuth2 client_credentials — Basic auth first, query-string fallback."""
    token_url = _env("RELTIO_TOKEN_URL", RELTIO_TOKEN_URL_DEFAULT)
    basic = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
    url = f"{token_url}?grant_type=client_credentials"
    headers = {
        "Authorization": f"Basic {basic}",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
    }
    try:
        data = http_json("POST", url, headers=headers, form_body="", timeout=timeout)
    except RuntimeError as first_err:
        qs = urllib.parse.urlencode(
            {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            }
        )
        try:
            data = http_json(
                "GET",
                f"{token_url}?{qs}",
                headers={"Accept": "application/json"},
                timeout=timeout,
            )
        except RuntimeError as second_err:
            raise SystemExit(
                "Reltio token request failed (401 usually means bad client_id/secret).\n"
                f"  client_id={client_id!r}\n"
                f"  client_secret length={len(client_secret)} "
                f"(starts {client_secret[:4]!r}…)\n"
                "  If the secret contains $ or *, keep it single-quoted in .env "
                "and do not `source .env` — this script loads .env itself.\n"
                f"  detail: {second_err}"
            ) from first_err

    if not data.get("access_token"):
        raise RuntimeError(f"Reltio token response missing access_token: {data}")
    return data


def adoc_headers(access_key: str, secret_key: str) -> Dict[str, str]:
    return {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "accessKey": access_key,
        "secretKey": secret_key,
    }


def list_mcp_servers(base_url: str, headers: Dict[str, str], timeout: int = 45) -> List[Dict[str, Any]]:
    url = f"{base_url.rstrip('/')}/ai/api/v1/mcp-servers"
    payload = http_json("GET", url, headers=headers, timeout=timeout)
    if isinstance(payload, list):
        return payload
    return payload.get("servers") or []


def resolve_server(
    servers: List[Dict[str, Any]],
    server_id: Optional[int],
    server_name: str,
    mcp_url: Optional[str],
) -> Dict[str, Any]:
    if server_id is not None:
        for s in servers:
            if s.get("id") == server_id:
                return s
        raise SystemExit(f"No MCP server with id={server_id}")

    name_l = (server_name or "").strip().lower()
    url_l = (mcp_url or "").rstrip("/").lower()

    matches: List[Dict[str, Any]] = []
    for s in servers:
        cfg = s.get("server_config") or {}
        if name_l and (cfg.get("name") or "").strip().lower() == name_l:
            matches.append(s)
        elif url_l and (cfg.get("url") or "").rstrip("/").lower() == url_l:
            matches.append(s)
        elif name_l and "reltio" in (cfg.get("name") or "").lower():
            matches.append(s)

    seen = set()
    uniq: List[Dict[str, Any]] = []
    for s in matches:
        if s.get("id") in seen:
            continue
        seen.add(s.get("id"))
        uniq.append(s)

    if not uniq:
        names = [
            f"{s.get('id')}:{(s.get('server_config') or {}).get('name')}"
            for s in servers
            if not (s.get("server_config") or {}).get("is_system")
        ]
        raise SystemExit(
            "Could not find Reltio MCP server. "
            f"Set ADOC_MCP_SERVER_ID or ADOC_MCP_SERVER_NAME. Known servers: {names}"
        )
    if len(uniq) > 1 and server_id is None and not mcp_url:
        ids = [f"{s.get('id')}:{(s.get('server_config') or {}).get('name')}" for s in uniq]
        raise SystemExit(f"Multiple matches {ids}; set ADOC_MCP_SERVER_ID")
    return uniq[0]


def update_bearer_token(
    base_url: str,
    headers: Dict[str, str],
    server: Dict[str, Any],
    access_token: str,
    timeout: int = 60,
) -> Dict[str, Any]:
    sid = server["id"]
    cfg = dict(server.get("server_config") or {})
    if not cfg.get("url") or not cfg.get("name"):
        raise RuntimeError(f"Server {sid} missing name/url in server_config")

    existing = list(cfg.get("headers") or [])
    new_headers: List[Dict[str, Any]] = []
    found = False
    for h in existing:
        key = (h.get("key") or "").strip()
        if key.lower() == "authorization":
            new_headers.append(
                {"key": "Authorization", "value": f"Bearer {access_token}", "is_secret": True}
            )
            found = True
        else:
            new_headers.append(h)
    if not found:
        new_headers.append(
            {"key": "Authorization", "value": f"Bearer {access_token}", "is_secret": True}
        )

    body = {
        "name": cfg["name"],
        "url": cfg["url"],
        "description": cfg.get("description") or "",
        "enabled": cfg.get("enabled", True),
        "headers": new_headers,
    }
    url = f"{base_url.rstrip('/')}/ai/api/v1/mcp-servers/{sid}"
    return http_json("PUT", url, headers=headers, body=body, timeout=timeout)


def mask_token(token: str) -> str:
    if len(token) <= 10:
        return "***"
    return f"{token[:6]}…{token[-4:]} (len={len(token)})"


def rotate_once(args: argparse.Namespace) -> int:
    client_id = _env("RELTIO_CLIENT_ID", required=True)
    client_secret = _env("RELTIO_CLIENT_SECRET", required=True)
    base_url = _env("ADOC_BASE_URL", required=True)
    access_key = _env("ADOC_ACCESS_KEY", required=True)
    secret_key = _env("ADOC_SECRET_KEY", required=True)
    server_name = _env("ADOC_MCP_SERVER_NAME", DEFAULT_MCP_NAME)
    mcp_url = _env("RELTIO_MCP_URL", None) or None
    server_id_raw = _env("ADOC_MCP_SERVER_ID", None) or None
    server_id = int(server_id_raw) if server_id_raw else None

    host = urllib.parse.urlparse(base_url).hostname or ""
    if "acceldata" not in host and not args.allow_any_host:
        raise SystemExit(
            f"ADOC_BASE_URL host looks unexpected ({host}); pass --allow-any-host if intentional"
        )

    print(f"[1/3] Fetching Reltio OAuth token for client_id={client_id} …")
    token_payload = fetch_reltio_token(client_id, client_secret)
    access_token = token_payload["access_token"]
    expires_in = int(token_payload.get("expires_in") or 0)
    print(f"      OK token={mask_token(access_token)} expires_in={expires_in}s")

    hdrs = adoc_headers(access_key, secret_key)
    print(f"[2/3] Listing MCP servers on {base_url} …")
    servers = list_mcp_servers(base_url, hdrs)
    server = resolve_server(servers, server_id, server_name, mcp_url)
    cfg = server.get("server_config") or {}
    print(f"      Target id={server.get('id')} name={cfg.get('name')!r} url={cfg.get('url')}")

    print("[3/3] Updating Authorization: Bearer <token> on ADOC MCP …")
    updated = update_bearer_token(base_url, hdrs, server, access_token)
    u_cfg = updated.get("server_config") or {}
    status = u_cfg.get("connection_status") or {}
    tools = status.get("discovered_tools") or []
    status_summary = {
        "is_connected": status.get("is_connected"),
        "error_message": status.get("error_message"),
        "last_check_time": status.get("last_check_time"),
        "discovered_tools_count": len(tools) if isinstance(tools, list) else None,
    }
    print(
        json.dumps(
            {
                "ok": True,
                "mcp_server_id": updated.get("id"),
                "name": u_cfg.get("name"),
                "url": u_cfg.get("url"),
                "updated_at": updated.get("updated_at"),
                "reltio_expires_in": expires_in,
                "connection_status": status_summary,
            },
            indent=2,
        )
    )
    if status and status.get("is_connected") is False:
        print(
            "Note: connection_status may be stale until you click Test Connection in ADOC UI. "
            "Confirm Reltio client has ROLE_EXECUTE_MCP on the tenant.",
            file=sys.stderr,
        )
    return expires_in


def main() -> int:
    load_dotenv(SCRIPT_DIR / ".env")

    parser = argparse.ArgumentParser(
        description="Rotate Reltio Bearer token into ADOC MCP server headers"
    )
    parser.add_argument(
        "--loop",
        action="store_true",
        help="Keep running; refresh before token expiry",
    )
    parser.add_argument(
        "--refresh-buffer-sec",
        type=int,
        default=int(os.environ.get("REFRESH_BUFFER_SEC", DEFAULT_REFRESH_BUFFER_SEC)),
        help="Seconds before expiry to refresh when using --loop (default: 1800)",
    )
    parser.add_argument(
        "--allow-any-host",
        action="store_true",
        help="Skip Acceldata hostname check on ADOC_BASE_URL",
    )
    args = parser.parse_args()

    if not args.loop:
        rotate_once(args)
        return 0

    print("Auto-rotate loop started (Ctrl+C to stop)")
    while True:
        try:
            expires_in = rotate_once(args)
            sleep_for = max(60, expires_in - args.refresh_buffer_sec) if expires_in else 6 * 3600
            print(f"Sleeping {sleep_for}s before next rotation …")
            time.sleep(sleep_for)
        except KeyboardInterrupt:
            print("Stopped.")
            return 0
        except Exception as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            print("Retrying in 60s …", file=sys.stderr)
            time.sleep(60)


if __name__ == "__main__":
    raise SystemExit(main())
