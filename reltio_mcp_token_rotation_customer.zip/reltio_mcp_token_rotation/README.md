# Reltio MCP token rotation for Acceldata (ADOC/ADM)

Keeps the **Authorization: Bearer** header on an Acceldata MCP server in sync with a fresh Reltio OAuth access token.

## Why

Reltio MCP expects `Authorization: Bearer <access_token>`. Tokens expire (typically ~9 hours). Acceldata stores that header on the MCP server (`Settings → Integrations → MCP Servers`). This script refreshes the token and updates ADOC via API so ADM does not need a manual edit each time.

## Prerequisites

- **Python 3.9+ only** — no install required (uses the standard library).
- `requests` is optional. If present it is used; otherwise the script falls back to `urllib`.

On Homebrew Python, `pip install` into the system interpreter is blocked (PEP 668). Prefer running without installs, or use a venv:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install requests   # optional
```

## One-time ADOC setup

1. In ADOC: **Settings → Integrations → MCP Servers → + Add Server**
2. Name: `Reltio MCP` (or note the server id)
3. URL: `https://<reltio-env>.reltio.com/ai/tools/mcp/` (must end with `/mcp` or `/mcp/`)
4. Auth: Bearer token — paste any current token once (script will overwrite it)
5. Confirm the Reltio OAuth client has `ROLE_EXECUTE_MCP` on the tenant

## Configure & run

```bash
cp .env.example .env
# Edit .env with your Reltio client + Acceldata API keys

python3 rotate_reltio_mcp_token.py
```

Do **not** `source .env` — the script loads it automatically.  
If a secret contains `$` or `*`, keep it **single-quoted** in `.env`:

```bash
RELTIO_CLIENT_SECRET='your$secret*here'
```

Continuous refresh (sidecar):

```bash
python3 rotate_reltio_mcp_token.py --loop
```

Cron every 6 hours:

```cron
0 */6 * * * cd /opt/reltio_mcp_token_rotation && /usr/bin/env python3 rotate_reltio_mcp_token.py >> /var/log/reltio_mcp_rotate.log 2>&1
```

## Package contents

| File | Purpose |
|------|---------|
| `rotate_reltio_mcp_token.py` | Main script |
| `requirements.txt` | `requests` only |
| `.env.example` | Template for credentials |
| `README.md` | This guide |

## API used

| Step | Call |
|------|------|
| Get token | `POST https://auth.reltio.com/oauth/token?grant_type=client_credentials` with Basic auth |
| List MCP | `GET {ADOC_BASE_URL}/ai/api/v1/mcp-servers` (`accessKey` / `secretKey` headers) |
| Update header | `PUT {ADOC_BASE_URL}/ai/api/v1/mcp-servers/{id}` with `Authorization: Bearer …` header |

## Acceldata access / secret key permissions

Yes — customers should use a **Service User** (service account), not a personal user key.

### Recommended setup

1. **Control Center → Security → Service Users → Create Service User**  
   ([Service Users docs](https://docs.acceldata.io/adoc/documentation/service-users))
2. Assign a **Tenant role** that can manage ADM Settings / MCP Servers:
   - Practical choice: built-in **tenant_admin** / **Owner** / **Admin**, **or**
   - A custom Tenant Role under **Control Center → Access Management → Tenant Roles** with Administration / settings access sufficient to open **Settings → Integrations → MCP Servers** and edit servers (Create + Modify + View).
3. Domain roles are **not** required for this rotation script (MCP config is tenant/settings-scoped, not asset-domain-scoped).
4. On the Service User: **Create API Key** → copy Access Key + Secret Key into `.env` (`ADOC_ACCESS_KEY` / `ADOC_SECRET_KEY`).
5. **Create (or own) the Reltio MCP server with that same Service User’s identity**  
   MCP server records are tied to the creating user (`user_id`). Keys from User A generally cannot update MCP servers created by User B. Either:
   - Add the Reltio MCP entry while authenticated as that Service User’s API identity (API create), or
   - Run the rotation with keys belonging to the same user who created the MCP server in the UI.

### Who can create Service Users?

A human admin needs **Service User Management** (Create) on their Tenant Role — typically Tenant Admin / Owner. The Service User itself only needs enough role to manage MCP settings + its own API key.

### Reltio side (separate from Acceldata)

The Reltio OAuth client must include `ROLE_EXECUTE_MCP` (and any MDM permissions the MCP tools need) on the target tenant.

## Security notes

- Never commit `.env` or share live secrets in tickets/chat.
- Prefer a Service User API key over a personal user key so rotation survives employee offboarding.
- Prefer a dedicated Reltio client with least privilege (`ROLE_EXECUTE_MCP` + needed MDM roles only).
- Store secrets in a secret manager in production.
